using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

public class UICard1 : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI nameText;
    [SerializeField] private TextMeshProUGUI costText;
    [SerializeField] private Image iconImage;
    [SerializeField] private RectTransform visualRoot; // �ν����Ϳ��� �� �Ҵ�!

    private CanvasGroup cg;
    private CardRawData myData;
    private UIManager uiManager;

    private void Awake()
    {
        cg = GetComponent<CanvasGroup>();
        if (visualRoot != null) visualRoot.anchoredPosition = Vector2.zero;
    }

    public void Setup(CardRawData data, UIManager manager)
    {
        myData = data;
        uiManager = manager;

        nameText.text = data.cardName;
        costText.text = data.cost.ToString();
        iconImage.sprite = data.cardIcon;

        Button btn = GetComponent<Button>();
        btn.onClick.RemoveAllListeners();
        btn.onClick.AddListener(() => uiManager.OnCardClicked(myData, this));

        cg.alpha = 1;
        cg.blocksRaycasts = true;
    }

    // [�ٽ�] ȭ�� ������ �ۿ��� ����ϰ� ����� �Լ�
    public void SetOffset(float distance)
    {
        visualRoot.anchoredPosition = new Vector2(distance, 0);
    }

    // [�ٽ�] �ʸ�ó�� �������� ���� �и��� �ִϸ��̼�
    public IEnumerator Co_MoveLeft(float distance, float duration)
    {
        float elapsed = 0;
        Vector2 startPos = visualRoot.anchoredPosition;
        Vector2 targetPos = startPos + new Vector2(-distance, 0);

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            // SmoothStep�� ��� ���ӵ��� �پ� ��ȭó�� �ε巴���ϴ�.
            float t = Mathf.SmoothStep(0, 1, elapsed / duration);
            visualRoot.anchoredPosition = Vector2.Lerp(startPos, targetPos, t);
            yield return null;
        }
        visualRoot.anchoredPosition = Vector2.zero;
    }

    public IEnumerator Co_FadeOut(float duration)
    {
        cg.blocksRaycasts = false;
        float elapsed = 0;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            cg.alpha = 1 - (elapsed / duration);
            yield return null;
        }
    }
}